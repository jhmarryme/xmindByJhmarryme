package cn.jhmarryme.dbc;

import java.sql.*;


/**
 * ���ݿ�������
 */
public class DatabaseConnection {
    private Connection conn = null;

    private static final String DBDIRVER = "com.mysql.jdbc.Driver";
    private static final String URL = "jdbc:mysql://localhost:3306/simplelogin";
    private static final String NAME = "root";
    private static final String PASSWORD = "541224";


    /**
     * �������ݿ����Ӷ���
     */
    public DatabaseConnection(){

        try {
            Class.forName(DBDIRVER);
            conn = DriverManager.getConnection(URL, NAME, PASSWORD);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {

        }
    }

    /**
     * ��ȡ���ݿ����Ӷ���
     * @return
     */
    public Connection getConn(){
        return this.conn;
    }

    public void close(){
        boolean bool = false;
        if (conn != null){
            try {
                conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}

package cn.jhmarryme.dao;

import cn.jhmarryme.dbc.DatabaseConnection;
import cn.jhmarryme.vo.User;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class UserDaoImpI implements IUserDao{

    private Connection conn = null;
    private PreparedStatement pstmt = null;

    public UserDaoImpI(Connection conn) {
        this.conn = conn;
    }

    @Override
    public boolean findLogin(User user) throws Exception {
        boolean bool = false;
        String sql = "select * from user where name = ? and password = ?";
        ResultSet rs = null;
        try {
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, user.getName());
            pstmt.setString(2, user.getPassword());
            rs = pstmt.executeQuery();
            if (rs.next()){
                bool = true;
            }
        }catch (Exception e){
            throw e;
        } finally {
            if (pstmt != null){
                try {
                    pstmt.close();
                }catch (Exception e){
                    throw e;
                }
            }
        }

        return bool;
    }
}

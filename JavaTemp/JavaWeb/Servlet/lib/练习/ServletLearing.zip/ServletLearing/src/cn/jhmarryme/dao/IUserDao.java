package cn.jhmarryme.dao;

import cn.jhmarryme.vo.User;

/**
 * DAO�ӿ�
 */

public interface IUserDao {

    public boolean findLogin(User user) throws Exception;
}

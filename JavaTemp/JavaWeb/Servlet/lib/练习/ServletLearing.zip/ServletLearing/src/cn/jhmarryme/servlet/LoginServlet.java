package cn.jhmarryme.servlet;

import cn.jhmarryme.dao.proxy.UserDaoProxy;
import cn.jhmarryme.vo.User;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class LoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public LoginServlet(){
        super();
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        String name = req.getParameter("name");
        String password = req.getParameter("password");

        List<String> info = new ArrayList<String>();

        if (name == null || "".equals(name)){
            info.add("�û�������Ϊ��");
            System.out.println("�û�������Ϊ��");
        }

        if (password == null || "".equals(password)){
            info.add("���벻��Ϊ��");
            System.out.println("���벻��Ϊ��");
        }

        if (info.size() == 0){
            User user = new User();
            user.setName(name);
            user.setPassword(password);

            UserDaoProxy userDaoProxy = new UserDaoProxy();

            try{
                if (userDaoProxy.findLogin(user)){
                    info.add("�û���¼�ɹ�, ��ӭ" + user.getName() + "����!");
                } else {
                    info.add("�û���¼ʧ��, ������û���������");
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        req.setAttribute("info", info);
        req.getRequestDispatcher("Login.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        this.doGet(req, resp);
    }
}

package cn.jhmarryme.dao.proxy;

import cn.jhmarryme.dao.IUserDao;
import cn.jhmarryme.dao.UserDaoImpI;
import cn.jhmarryme.dbc.DatabaseConnection;
import cn.jhmarryme.vo.User;

import java.sql.Connection;
import java.sql.DatabaseMetaData;


/**
 * UserDaoImpI�Ĵ�����
 */
public class UserDaoProxy implements IUserDao {

    IUserDao iUserDao = null;//����DAO�ӿ�
    DatabaseConnection dbc = null;//�������ݿ�����

    public UserDaoProxy() {
        try {
            dbc = new DatabaseConnection();//ʵ�������ݿ�����

        } catch (Exception e){
            throw e;
        }
        iUserDao = new UserDaoImpI(dbc.getConn());
    }

    @Override
    public boolean findLogin(User user) throws Exception {
        boolean bool = false;

        try {
            bool = this.iUserDao.findLogin(user);
        } catch (Exception e){
            throw e;
        } finally {
            dbc.close();
        }


        return bool;
    }
}

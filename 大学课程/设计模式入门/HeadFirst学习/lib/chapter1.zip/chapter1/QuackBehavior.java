package chapter1;

public interface QuackBehavior {
    public void quack();
}

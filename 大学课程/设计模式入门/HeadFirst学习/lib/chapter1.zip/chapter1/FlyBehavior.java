package chapter1;

public interface FlyBehavior {

    public void fly();
}
